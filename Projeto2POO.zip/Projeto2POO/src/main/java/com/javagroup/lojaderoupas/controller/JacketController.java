package com.javagroup.lojaderoupas.controller;

import static ch.qos.logback.core.util.OptionHelper.isNullOrEmpty;

import com.javagroup.lojaderoupas.exception.IdDuplicatedException;
import com.javagroup.lojaderoupas.exception.IdDoesNotExistException;
import com.javagroup.lojaderoupas.model.Jacket;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Controller;

@Controller
public class JacketController {
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public JacketController(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    private void validateJacket(Jacket jacket) {
        if (isNullOrEmpty(jacket.getName()) || isNullOrEmpty(jacket.getColor()) || isNullOrEmpty(jacket.getSize()) || jacket.getPrice() <= 0 || isNullOrEmpty(jacket.getBrand())) {
            throw new NumberFormatException();
        }
    }

    public void save(Jacket jacket) throws IdDuplicatedException, NumberFormatException {
        try {
            validateJacket(jacket);

            String sql = "INSERT INTO Clothings " + "(name, color, size, price, brand) " + "VALUES (?, ?, ?, ?, ?)";

            KeyHolder keyHolder = new GeneratedKeyHolder();
            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS );

                ps.setString(1, jacket.getName());
                ps.setString(2, jacket.getColor());
                ps.setString(3, jacket.getSize());
                ps.setDouble(4, jacket.getPrice());
                ps.setString(5, jacket.getBrand());

                return ps;
            }, keyHolder);

            int idClothing = keyHolder.getKey().intValue();
            String sql2 = "INSERT INTO Jackets " + "(idClothing, waterproof) " + "VALUES (?, ?)";

            jdbcTemplate.update(sql2, idClothing, jacket.isWaterproof());
            jacket.setId(idClothing);
            
            JOptionPane.showMessageDialog(null, "JAQUETA CADASTRADA COM SUCESSO!", "CADASTRO DE JAQUETA", JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO CADASTRO DE JAQUETA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "DADO CADASTRADO ERRADO OU VAZIO!", "ERRO NO CADASTRO DE JAQUETA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "TIPO DE DADO CADASTRADO ERRADO!", "ERRO NO CADASTRO DE JAQUETA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IdDuplicatedException ide) {
            ide.screenException();
        }
    }

    public void update(Jacket jacket) throws IdDoesNotExistException, NumberFormatException {
        try {
            String checkSql = "SELECT COUNT(*) FROM Clothings WHERE id = ?";

            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{jacket.getId()},Integer.class);
            
            if (count == 0) {
                throw new IdDoesNotExistException();
            }

            validateJacket(jacket);
            String sql = "UPDATE Clothings SET " + "name = ?, " + "color = ?, " + "size = ?, " + "price = ?, " + "brand = ? " + "WHERE id = ?";
            jdbcTemplate.update(sql, jacket.getName(), jacket.getColor(), jacket.getSize(), jacket.getPrice(), jacket.getBrand(), jacket.getId());
            String sql2 = "UPDATE Jackets SET " + "waterproof = ? " + "WHERE idClothing = ?";
            jdbcTemplate.update(sql2, jacket.isWaterproof(), jacket.getId());

            JOptionPane.showMessageDialog(null, "JAQUETA ATUALIZADA COM SUCESSO!", "ATUALIZAÇÃO DE JAQUETA", JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "DADO CADASTRADO ERRADO OU VAZIO!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "TIPO DE DADO CADASTRADO ERRADO!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IdDoesNotExistException ide) {
            ide.screenException();
        }
    }

    public void delete(Integer id) {
        try {
            if (id == null) {
                throw new NumberFormatException();
            }

            String sql = "DELETE FROM Jacket WHERE idClothing = ?";
            jdbcTemplate.update(sql, id);
            String sql2 = "DELETE FROM Clothings WHERE id = ?";
            jdbcTemplate.update(sql2, id);

            JOptionPane.showMessageDialog(null, "JAQUETA DELETADA COM SUCESSO!", "DELETE DE JAQUETA", JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO DELETE", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "ID INVÁLIDO OU VAZIO!", "ERRO NO DELETE", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void consultAll(DefaultTableModel tableModel) {
        try {
            String sql = "SELECT c.id, c.name, c.color, c.size, " + "c.price, c.brand, j.isWaterproof " + "FROM Clothings c "+ "INNER JOIN Jacket j ON c.id = j.idClothing";

            List<Jacket> listJacket = jdbcTemplate.query(
                sql,
                (ResultSet rs, int rowNum) -> {
                    Jacket jacket = new Jacket();

                    jacket.setId(rs.getInt("id"));
                    jacket.setName(rs.getString("name"));
                    jacket.setColor(rs.getString("color"));
                    jacket.setSize(rs.getString("size"));
                    jacket.setPrice(rs.getDouble("price"));
                    jacket.setWaterproof(rs.getBoolean("isWaterproof"));
                    jacket.setBrand(rs.getString("brand"));
                    return jacket;
                }
            );

            tableModel.setRowCount(0);

            for (Jacket jacket : listJacket) {
                tableModel.addRow(new Object[]{
                    jacket.getId(),
                    jacket.getName(),
                    jacket.getColor(),
                    jacket.getSize(),
                    jacket.getPrice(),
                    jacket.isWaterproof(),
                    jacket.getBrand(),
                });
            }
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA CONSULTA DE JAQUETA", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void consultJacket(Integer id, DefaultTableModel tableModel) throws IdDoesNotExistException {
        try {
            String checkSql ="SELECT COUNT(*) FROM Clothings WHERE id = ?";
            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{id}, Integer.class);

            if (count == 0) {
                throw new IdDoesNotExistException();
            }

            String sql = "SELECT c.id, c.name, c.color, c.size, " + "c.price, c.brand, j.isWaterproof " + "FROM Clothings c " + "INNER JOIN Jacket j ON c.id = j.idClothing "+ "WHERE c.id = ?";
            Jacket jacket = jdbcTemplate.queryForObject(
                sql,
                new Object[]{id},
                (ResultSet rs, int rowNum) -> {
                    Jacket jacketAux = new Jacket();

                    jacketAux.setId(rs.getInt("id"));
                    jacketAux.setName(rs.getString("name"));
                    jacketAux.setColor(rs.getString("color"));
                    jacketAux.setSize(rs.getString("size"));
                    jacketAux.setPrice(rs.getDouble("price"));
                    jacketAux.setWaterproof(rs.getBoolean("isWaterproof"));
                    jacketAux.setBrand(rs.getString("brand"));
                    return jacketAux;
                }
            );

            tableModel.setRowCount(0);

            tableModel.addRow(new Object[]{
                jacket.getId(),
                jacket.getName(),
                jacket.getColor(),
                jacket.getSize(),
                jacket.getPrice(),
                jacket.isWaterproof(),
                jacket.getBrand()
            });
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "CONSULTA DE JAQUETA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IdDoesNotExistException ide) {
            ide.screenException();
        }
    }
}