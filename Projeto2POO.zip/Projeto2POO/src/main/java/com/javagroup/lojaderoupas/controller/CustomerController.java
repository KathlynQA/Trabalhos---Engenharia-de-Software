package com.javagroup.lojaderoupas.controller;

import com.javagroup.lojaderoupas.exception.UserException;
import com.javagroup.lojaderoupas.exception.WrongDataException;
import com.javagroup.lojaderoupas.model.Customer;
import static com.mysql.cj.util.StringUtils.isNullOrEmpty;
import java.sql.ResultSet;
import javax.sql.DataSource;
import javax.swing.JOptionPane;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;


@Controller
public class CustomerController {
    
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public CustomerController(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }
    
    public void validateCustomer(Customer customer) {
        if (isNullOrEmpty(customer.getName()) || isNullOrEmpty(customer.getCpf()) || customer.getName() == null || customer.getCpf() == null) {
                throw new NumberFormatException();
        }
    }
    
    public String returnPassword(String password, String name){
        if(isNullOrEmpty(password)){
            String passwordSql = "SELECT password FROM User WHERE name = ?";
            password = jdbcTemplate.queryForObject(passwordSql, new Object[]{name}, String.class);
        }
        
        return password;
    } 
    
    public String returnAddress(String address, String name){
        if(isNullOrEmpty(address)){
            String addressSql = "SELECT address FROM User WHERE name = ?";
            address = jdbcTemplate.queryForObject(addressSql, new Object[]{name}, String.class);
        }
        
        return address;
    } 
        
    public String returnEmail(String email, String name){
        if(isNullOrEmpty(email)){
            String emailSql = "SELECT email FROM User WHERE name = ?";
            email = jdbcTemplate.queryForObject(emailSql, new Object[]{name}, String.class);
        }
        
        return email;
    } 
            
    public String returnPhone(String phone, String name){
        if(isNullOrEmpty(phone)){
            String phoneSql = "SELECT phone FROM User WHERE name = ?";
            phone = jdbcTemplate.queryForObject(phoneSql, new Object[]{name}, String.class);
        }
        
        return phone;
    } 
    
    public void save(Customer customer) {
        try{
            validateCustomer(customer);
            
            String sqlUser = "INSERT INTO User (category, name, address, email, phone, password) VALUES (?, ?, ?, ?, ?, ?)";
            jdbcTemplate.update(sqlUser, customer.getCategory(), customer.getName(), customer.getAddress(), customer.getEmail(), customer.getPhone(), customer.getPassword());
            
            String checkSql = "SELECT id FROM User WHERE name = ?";
            Integer generatedUserId = jdbcTemplate.queryForObject(checkSql, new Object[]{customer.getName()}, Integer.class);
            
            String sqlCustomer = "INSERT INTO Customer (idUser, cpf) VALUES (?, ?)";
            jdbcTemplate.update(sqlCustomer, generatedUserId, customer.getCpf());
            
            JOptionPane.showMessageDialog(null, "USUÁRIO CADASTRADO COM SUCESSO!", "CADASTRO DE USUÁRIO", 1);
        }
        
        catch (DataAccessException ex){
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO CADASTRO DE USUÁRIO", 0);
        }
        
        catch (NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "TIPO DE DADO CADASTRADO ERRADO OU VAZIO!", "ERRO NA ATUALIZAÇÃO NO CADASTRO DE USUÁRIO", 0);
        }
        
    } 
   
    public Customer loginCustomer(String name, String password) throws UserException {
        try {
            String sql =
                "SELECT u.id, u.name, u.email, u.password " +
                "FROM `User` u " +
                "INNER JOIN Customer c ON u.id = c.idUser " +
                "WHERE u.name = ? AND u.password = ?";

            Customer customer = jdbcTemplate.queryForObject(
                sql,
                new Object[]{name, password},
                (ResultSet rs, int rowNum) -> {
                    Customer customerAux = new Customer();

                    customerAux.setId(rs.getInt("id"));
                    customerAux.setName(rs.getString("name"));
                    customerAux.setEmail(rs.getString("email"));
                    customerAux.setPassword(rs.getString("password"));

                    return customerAux;
                }
            );

            return customer;
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "DADOS INCORRETOS OU USUÁRIO INEXISTENTE", "LOGIN DE CLIENTE", JOptionPane.ERROR_MESSAGE);
            return null;
        } 
        
        catch (UserException ue) {
            ue.screenException();
            return null;
        }
    }
}