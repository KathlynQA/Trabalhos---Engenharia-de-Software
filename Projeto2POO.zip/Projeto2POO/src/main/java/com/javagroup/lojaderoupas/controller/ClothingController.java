package com.javagroup.lojaderoupas.controller;

import com.javagroup.lojaderoupas.exception.ClothingNotAvailableException;
import com.javagroup.lojaderoupas.model.Clothing;
import com.javagroup.lojaderoupas.model.Customer;
import com.javagroup.lojaderoupas.model.Employee;
import com.javagroup.lojaderoupas.model.Jacket;
import com.javagroup.lojaderoupas.model.Pants;
import com.javagroup.lojaderoupas.model.Sale;
import com.javagroup.lojaderoupas.model.TShirt;
import java.sql.ResultSet;
import java.util.List;
import javax.sql.DataSource;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.dao.EmptyResultDataAccessException;

@Controller
public class ClothingController {
    private final JdbcTemplate jdbcTemplate;
    private final SaleController saleController;

    @Autowired
    public ClothingController(DataSource dataSource, SaleController saleController) {
        jdbcTemplate = new JdbcTemplate(dataSource);
        this.saleController = saleController;
    }

    public Boolean verifyClothingId(Integer id) throws ClothingNotAvailableException {
        try {
            if (id == null) {
                throw new ClothingNotAvailableException();
            }

            String sql = "SELECT COUNT(*) FROM Clothings WHERE id = ?";
            int count = jdbcTemplate.queryForObject(sql, new Object[]{id}, Integer.class);

            if (count == 0) {
                throw new ClothingNotAvailableException();
            }

            return true;
       } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA CONSULTA DE ROUPA", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    public void create(Clothing clothing) {
        try {
            if (clothing == null || clothing.getId() == null || clothing.getName() == null || clothing.getName().isEmpty() || clothing.getColor() == null || clothing.getColor().isEmpty() 
                || clothing.getSize() == null || clothing.getSize().isEmpty() || clothing.getPrice() <= 0 || clothing.getBrand() == null || clothing.getBrand().isEmpty()) {
                throw new NumberFormatException();
            }

            String checkSql = "SELECT COUNT(*) FROM Clothings WHERE id = ?";
            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{clothing.getId()}, Integer.class);

            if (count > 0) {
                JOptionPane.showMessageDialog(null, "ID DA ROUPA JÁ CADASTRADO!", "ERRO NO CADASTRO", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sql = "INSERT INTO Clothings " + "(id, name, color, size, price, brand) " + "VALUES (?, ?, ?, ?, ?, ?)";
            jdbcTemplate.update(sql, clothing.getId(), clothing.getName(), clothing.getColor(), clothing.getSize(), clothing.getPrice(), clothing.getBrand());

            if (clothing instanceof Pants) {
                Pants pants = (Pants)clothing;
                String sqlPants = "INSERT INTO Pants (idClothing, pantsType) " + "VALUES (?, ?)";
                jdbcTemplate.update(sqlPants, pants.getPantsType());
            } 
            
            else if (clothing instanceof TShirt) {
                TShirt tShirt = (TShirt)clothing;
                String sqlTShirt = "INSERT INTO TShirts (idClothing, sleeveType) " +"VALUES (?, ?)";
                jdbcTemplate.update(sqlTShirt, tShirt.getSleeveType());
            } 
            
            else if (clothing instanceof Jacket) {
                Jacket jacket = (Jacket)clothing;
                String sqlJacket = "INSERT INTO Jackets (idClothing, waterproof) " + "VALUES (?, ?)";
                jdbcTemplate.update(sqlJacket, jacket.isWaterproof());
            }
            JOptionPane.showMessageDialog(null, "ROUPA CADASTRADA COM SUCESSO!", "CADASTRO DE ROUPA", JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO CADASTRO DE ROUPA",JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "DADOS DA ROUPA INVÁLIDOS OU VAZIOS!", "ERRO NO CADASTRO DE ROUPA", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void update(Clothing clothing) {
        try {
            if (clothing == null || clothing.getId() == null || clothing.getName() == null || clothing.getName().isEmpty() || clothing.getColor() == null
                || clothing.getColor().isEmpty() || clothing.getSize() == null || clothing.getSize().isEmpty() || clothing.getPrice() <= 0 || clothing.getBrand() == null || clothing.getBrand().isEmpty()) {
                throw new NumberFormatException();
            }

            String checkSql = "SELECT COUNT(*) FROM Clothings WHERE id = ?";
            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{clothing.getId()}, Integer.class);

            if (count == 0) {
                JOptionPane.showMessageDialog(null, "ID DA ROUPA NÃO EXISTE!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sql = "UPDATE Clothings SET " + "name = ?, color = ?, size = ?, price = ?, brand = ? " + "WHERE id = ?";

            jdbcTemplate.update(sql, clothing.getName(), clothing.getColor(), clothing.getSize(), clothing.getPrice(), clothing.getBrand(), clothing.getId());

            if (clothing instanceof Pants) {
                Pants pants = (Pants) clothing;
                String sqlPants = "UPDATE Pants SET pantsType = ? " + "WHERE idClothing = ?";
                jdbcTemplate.update(sqlPants, pants.getPantsType(), pants.getId());
            } 
            
            else if (clothing instanceof TShirt) {
                TShirt tShirt = (TShirt) clothing;
                String sqlTShirt = "UPDATE TShirts SET sleeveType = ? " + "WHERE idClothing = ?";
                jdbcTemplate.update(sqlTShirt, tShirt.getSleeveType(),tShirt.getId());
            } 
            
            else if (clothing instanceof Jacket) {
                Jacket jacket = (Jacket) clothing;
                String sqlJacket = "UPDATE Jackets SET waterproof = ? " + "WHERE idClothing = ?";
                jdbcTemplate.update(sqlJacket, jacket.isWaterproof(), jacket.getId());
            }
            JOptionPane.showMessageDialog(null, "ROUPA ATUALIZADA COM SUCESSO!", "ATUALIZAÇÃO DE ROUPA", JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA ATUALIZAÇÃO DE ROUPA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "DADOS DA ROUPA INVÁLIDOS OU VAZIOS!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void delete(Integer id) {
        try {
            if (id == null) {
                throw new NumberFormatException();
            }

            String checkSql = "SELECT COUNT(*) FROM Clothings WHERE id = ?";
            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{id}, Integer.class);

            if (count == 0) {
                JOptionPane.showMessageDialog(null, "ID DA ROUPA NÃO EXISTE!", "ERRO NO DELETE", JOptionPane.ERROR_MESSAGE);
                return;
            }

            jdbcTemplate.update("DELETE FROM Pants WHERE idClothing = ?", id);
            jdbcTemplate.update("DELETE FROM TShirts WHERE idClothing = ?", id);
            jdbcTemplate.update("DELETE FROM Jackets WHERE idClothing = ?", id);
            jdbcTemplate.update("DELETE FROM Clothings WHERE id = ?", id);
            JOptionPane.showMessageDialog(null, "ROUPA DELETADA COM SUCESSO!", "DELETE DE ROUPA", JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO DELETE DE ROUPA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "ID DA ROUPA INVÁLIDO OU VAZIO!", "ERRO NO DELETE", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public TShirt getTShirt(Integer id) throws ClothingNotAvailableException {
        try {
            if (id == null) {
                throw new ClothingNotAvailableException();
            }

            String sql =
                "SELECT c.id, c.name, c.color, c.size, c.price, c.brand, " +
                "t.sleeveType " +
                "FROM Clothings c " +
                "INNER JOIN TShirts t ON c.id = t.idClothing " +
                "WHERE c.id = ?";

            return jdbcTemplate.queryForObject(sql, new Object[]{id}, (ResultSet rs, int rowNum) -> {
                TShirt tShirt = new TShirt();

                tShirt.setId(rs.getInt("id"));
                tShirt.setName(rs.getString("name"));
                tShirt.setColor(rs.getString("color"));
                tShirt.setSize(rs.getString("size"));
                tShirt.setPrice(rs.getDouble("price"));
                tShirt.setBrand(rs.getString("brand"));
                tShirt.setSleeveType(rs.getString("sleeveType"));

                return tShirt;
            });
        } 

        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA CONSULTA DA CAMISETA", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    public Pants getPants(Integer id) throws ClothingNotAvailableException {
        try {
            if (id == null) {
                throw new ClothingNotAvailableException();
            }

            String sql =
                "SELECT c.id, c.name, c.color, c.size, c.price, c.brand, " +
                "p.pantsType " +
                "FROM Clothings c " +
                "INNER JOIN Pants p ON c.id = p.idClothing " +
                "WHERE c.id = ?";

            return jdbcTemplate.queryForObject(
                sql,
                new Object[]{id},
                (ResultSet rs, int rowNum) -> {
                    Pants pants = new Pants();

                    pants.setId(rs.getInt("id"));
                    pants.setName(rs.getString("name"));
                    pants.setColor(rs.getString("color"));
                    pants.setSize(rs.getString("size"));
                    pants.setPrice(rs.getDouble("price"));
                    pants.setBrand(rs.getString("brand"));
                    pants.setPantsType(rs.getString("pantsType"));

                    return pants;
                }
            );

        } 
        
        catch (EmptyResultDataAccessException ex) {
            throw new ClothingNotAvailableException();
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA CONSULTA DA CALÇA", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    
    public Jacket getJacket(Integer id) throws ClothingNotAvailableException {
        try {
            if (id == null) {
                throw new ClothingNotAvailableException();
            }

            String sql =
                "SELECT c.id, c.name, c.color, c.size, c.price, c.brand, " +
                "j.waterproof " +
                "FROM Clothings c " +
                "INNER JOIN Jackets j ON c.id = j.idClothing " +
                "WHERE c.id = ?";

            return jdbcTemplate.queryForObject(sql, new Object[]{id}, (ResultSet rs, int rowNum) -> {
                Jacket jacket = new Jacket();

                jacket.setId(rs.getInt("id"));
                jacket.setName(rs.getString("name"));
                jacket.setColor(rs.getString("color"));
                jacket.setSize(rs.getString("size"));
                jacket.setPrice(rs.getDouble("price"));
                jacket.setBrand(rs.getString("brand"));
                jacket.setWaterproof(rs.getBoolean("waterproof"));

                return jacket;
            });

        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA CONSULTA DA JAQUETA", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    
    public void consultAll(DefaultTableModel tableModel) {
        try {
            String sql =
                "SELECT c.id, c.name, c.color, c.size, c.price, c.brand, " +
                "CASE " +
                    "WHEN t.idClothing IS NOT NULL THEN 'Camiseta' " +
                    "WHEN p.idClothing IS NOT NULL THEN 'Calça' " +
                    "WHEN j.idClothing IS NOT NULL THEN 'Jaqueta' " +
                "END AS clothingType " +
                "FROM Clothings c " +
                "LEFT JOIN TShirts t ON c.id = t.idClothing " +
                "LEFT JOIN Pants p ON c.id = p.idClothing " +
                "LEFT JOIN Jackets j ON c.id = j.idClothing " +
                "ORDER BY c.id";

            List<Object[]> clothes = jdbcTemplate.query(
                sql,
                (ResultSet rs, int rowNum) -> new Object[]{
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("color"),
                    rs.getString("size"),
                    rs.getDouble("price"),
                    rs.getString("brand"),
                    rs.getString("clothingType")
                }
            );

            tableModel.setRowCount(0);

            for (Object[] clothing : clothes) {
                tableModel.addRow(clothing);
            }
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA CONSULTA DE ROUPAS", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public Clothing getClothing(Integer id) throws ClothingNotAvailableException {
        try {
            if (id == null) {
                throw new ClothingNotAvailableException();
            }

            String sql =
                "SELECT c.id, c.name, c.color, c.size, c.price, c.brand, " +
                "t.sleeveType, " +
                "p.pantsType, " +
                "j.waterproof, " +
                "CASE " +
                    "WHEN t.idClothing IS NOT NULL THEN 'Camiseta' " +
                    "WHEN p.idClothing IS NOT NULL THEN 'Calça' " +
                    "WHEN j.idClothing IS NOT NULL THEN 'Jaqueta' " +
                "END AS clothingType " +
                "FROM Clothings c " +
                "LEFT JOIN TShirts t ON c.id = t.idClothing " +
                "LEFT JOIN Pants p ON c.id = p.idClothing " +
                "LEFT JOIN Jackets j ON c.id = j.idClothing " +
                "WHERE c.id = ?";

            return jdbcTemplate.queryForObject(
                sql,
                new Object[]{id},
                (ResultSet rs, int rowNum) -> {

                    String type = rs.getString("clothingType");

                    if ("Camiseta".equals(type)) {
                        TShirt tShirt = new TShirt();

                        tShirt.setId(rs.getInt("id"));
                        tShirt.setName(rs.getString("name"));
                        tShirt.setColor(rs.getString("color"));
                        tShirt.setSize(rs.getString("size"));
                        tShirt.setPrice(rs.getDouble("price"));
                        tShirt.setBrand(rs.getString("brand"));
                        tShirt.setSleeveType(rs.getString("sleeveType"));

                        return tShirt;
                    }

                    if ("Calça".equals(type)) {
                        Pants pants = new Pants();

                        pants.setId(rs.getInt("id"));
                        pants.setName(rs.getString("name"));
                        pants.setColor(rs.getString("color"));
                        pants.setSize(rs.getString("size"));
                        pants.setPrice(rs.getDouble("price"));
                        pants.setBrand(rs.getString("brand"));
                        pants.setPantsType(rs.getString("pantsType"));

                        return pants;
                    }

                    if ("Jaqueta".equals(type)) {
                        Jacket jacket = new Jacket();

                        jacket.setId(rs.getInt("id"));
                        jacket.setName(rs.getString("name"));
                        jacket.setColor(rs.getString("color"));
                        jacket.setSize(rs.getString("size"));
                        jacket.setPrice(rs.getDouble("price"));
                        jacket.setBrand(rs.getString("brand"));
                        jacket.setWaterproof(rs.getBoolean("waterproof"));

                        return jacket;
                    }

                    return null;
                }
            );

        } 
        
        catch (EmptyResultDataAccessException ex) {
            throw new ClothingNotAvailableException();
        }

        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA CONSULTA DA ROUPA", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
}