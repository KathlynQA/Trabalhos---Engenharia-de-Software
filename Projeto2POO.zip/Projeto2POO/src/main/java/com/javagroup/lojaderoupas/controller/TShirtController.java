package com.javagroup.lojaderoupas.controller;

import static ch.qos.logback.core.util.OptionHelper.isNullOrEmpty;

import com.javagroup.lojaderoupas.exception.IdDuplicatedException;
import com.javagroup.lojaderoupas.exception.IdDoesNotExistException;
import com.javagroup.lojaderoupas.model.TShirt;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Controller;

@Controller
public class TShirtController {
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public TShirtController(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    private void validateTShirt(TShirt tShirt) {
        if (isNullOrEmpty(tShirt.getName()) || isNullOrEmpty(tShirt.getColor()) || isNullOrEmpty(tShirt.getSize()) || tShirt.getPrice() <= 0 || isNullOrEmpty(tShirt.getBrand()) || isNullOrEmpty(tShirt.getSleeveType())) {
            throw new NumberFormatException();
        }
    }

    public void save(TShirt tShirt) throws IdDuplicatedException, NumberFormatException {
        try {
            validateTShirt(tShirt);

            String sql = "INSERT INTO Clothings " + "(name, color, size, price, brand) " + "VALUES (?, ?, ?, ?, ?)";
            KeyHolder keyHolder = new GeneratedKeyHolder();

            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement( sql, Statement.RETURN_GENERATED_KEYS);
                ps.setString(1, tShirt.getName());
                ps.setString(2, tShirt.getColor());
                ps.setString(3, tShirt.getSize());
                ps.setDouble(4, tShirt.getPrice());
                ps.setString(5, tShirt.getBrand());

                return ps;
            }, keyHolder);

            int idClothing = keyHolder.getKey().intValue();

            String sql2 = "INSERT INTO TShirts " + "(idClothing, sleeveType) " + "VALUES (?, ?)";
            
            jdbcTemplate.update(sql2, idClothing, tShirt.getSleeveType());
            tShirt.setId(idClothing);
            JOptionPane.showMessageDialog(null, "CAMISETA CADASTRADA COM SUCESSO!", "CADASTRO DE CAMISETA", JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO CADASTRO DE CAMISETA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "DADO CADASTRADO ERRADO OU VAZIO!", "ERRO NO CADASTRO DE CAMISETA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "TIPO DE DADO CADASTRADO ERRADO!", "ERRO NO CADASTRO DE CAMISETA",JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IdDuplicatedException ide) {
            ide.screenException();
        }
    }

    public void update(TShirt tShirt) throws IdDoesNotExistException, NumberFormatException {
        try {
            String checkSql = "SELECT COUNT(*) FROM Clothings WHERE id = ?";

            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{tShirt.getId()},Integer.class);
            
            if (count == 0) {
                throw new IdDoesNotExistException();
            }

            validateTShirt(tShirt);
            String sql = "UPDATE Clothings SET " + "name = ?, " + "color = ?, " + "size = ?, " + "price = ?, " + "brand = ? " + "WHERE id = ?";
            jdbcTemplate.update(sql, tShirt.getName(), tShirt.getColor(), tShirt.getSize(), tShirt.getPrice(), tShirt.getBrand(), tShirt.getId());
            String sql2 = "UPDATE TShirts SET " + "sleeveType = ? "+ "WHERE idClothing = ?";
            jdbcTemplate.update(sql2, tShirt.getSleeveType(),tShirt.getId());

            JOptionPane.showMessageDialog(null, "CAMISETA ATUALIZADA COM SUCESSO!", "ATUALIZAÇÃO DE CAMISETA",JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "DADO CADASTRADO ERRADO OU VAZIO!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "TIPO DE DADO CADASTRADO ERRADO!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IdDoesNotExistException ide) {
            ide.screenException();
        }
    }

    public void delete(Integer id) {
        try {
            if (id == null) {
                throw new NumberFormatException();
            }

            String sql = "DELETE FROM TShirts WHERE idClothing = ?";
            jdbcTemplate.update(sql, id);
            String sql2 = "DELETE FROM Clothings WHERE id = ?";
            jdbcTemplate.update(sql2, id);

            JOptionPane.showMessageDialog(null, "CAMISETA DELETADA COM SUCESSO!", "DELETE DE CAMISETA",JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO DELETE",JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "ID INVÁLIDO OU VAZIO!", "ERRO NO DELETE",JOptionPane.ERROR_MESSAGE);
        }
    }

    public void consultAll(DefaultTableModel tableModel) {
        try {
            String sql = "SELECT c.id, c.name, c.color, c.size, " + "c.price, c.brand, t.sleeveType " + "FROM Clothings c "+ "INNER JOIN TShirts t ON c.id = t.idClothing";

            List<TShirt> listTShirt = jdbcTemplate.query(
                sql,
                (ResultSet rs, int rowNum) -> {
                    TShirt tShirt = new TShirt();

                    tShirt.setId(rs.getInt("id"));
                    tShirt.setName(rs.getString("name"));
                    tShirt.setColor(rs.getString("color"));
                    tShirt.setSize(rs.getString("size"));
                    tShirt.setPrice(rs.getDouble("price"));
                    tShirt.setBrand(rs.getString("brand"));
                    tShirt.setSleeveType(rs.getString("sleeveType"));
                    return tShirt;
                }
            );

            tableModel.setRowCount(0);

            for (TShirt tShirt : listTShirt) {
                tableModel.addRow(new Object[]{
                    tShirt.getId(),
                    tShirt.getName(),
                    tShirt.getColor(),
                    tShirt.getSize(),
                    tShirt.getPrice(),
                    tShirt.getSleeveType(),
                    tShirt.getBrand()
                });
            }
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA CONSULTA DE CAMISETAS", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void consultTShirt(Integer id, DefaultTableModel tableModel) throws IdDoesNotExistException {
        try {
            String checkSql ="SELECT COUNT(*) FROM Clothings WHERE id = ?";
            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{id}, Integer.class);

            if (count == 0) {
                throw new IdDoesNotExistException();
            }

            String sql = "SELECT c.id, c.name, c.color, c.size, " + "c.price, c.brand, t.sleeveType " + "FROM Clothings c " + "INNER JOIN TShirts t ON c.id = t.idClothing "+ "WHERE c.id = ?";
            TShirt tShirt = jdbcTemplate.queryForObject(
                sql,
                new Object[]{id},
                (ResultSet rs, int rowNum) -> {
                    TShirt tShirtAux = new TShirt();

                    tShirtAux.setId(rs.getInt("id"));
                    tShirtAux.setName(rs.getString("name"));
                    tShirtAux.setColor(rs.getString("color"));
                    tShirtAux.setSize(rs.getString("size"));
                    tShirtAux.setPrice(rs.getDouble("price"));
                    tShirtAux.setSleeveType(rs.getString("sleeveType"));
                    tShirtAux.setBrand(rs.getString("brand"));

                    return tShirtAux;
                }
            );

            tableModel.setRowCount(0);

            tableModel.addRow(new Object[]{
                tShirt.getId(),
                tShirt.getName(),
                tShirt.getColor(),
                tShirt.getSize(),
                tShirt.getPrice(),
                tShirt.getSleeveType(),
                tShirt.getBrand()
            });
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "CONSULTA DE CAMISETA",JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IdDoesNotExistException ide) {
            ide.screenException();
        }
    }
}