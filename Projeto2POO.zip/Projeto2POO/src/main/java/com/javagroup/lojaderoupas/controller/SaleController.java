package com.javagroup.lojaderoupas.controller;

import com.javagroup.lojaderoupas.model.Sale;
import com.javagroup.lojaderoupas.model.Customer;
import com.javagroup.lojaderoupas.model.Clothing;

import java.sql.ResultSet;
import java.util.List;

import javax.sql.DataSource;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class SaleController {
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public SaleController(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    private void validateSale(Sale sale) {
        if (sale.getCustomer() == null || sale.getClothing() == null) {
            throw new NumberFormatException();
        }
    }

    public void save(Sale sale) {
        validateSale(sale);
        String sql = "INSERT INTO Sale " + "(idCustomer, idClothing) " + "VALUES (?, ?)";

        jdbcTemplate.update(sql, sale.getCustomer().getId(), sale.getClothing().getId());
    }

    public void delete(Integer id) {
        try {
            if (id == null) {
                throw new NumberFormatException();
            }

            String checkSql = "SELECT COUNT(*) FROM Sale WHERE id = ?";
            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{id}, Integer.class);

            if (count == 0) {
                JOptionPane.showMessageDialog(null, "ID DA VENDA NÃO EXISTE!", "ERRO NO DELETE DE VENDA", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String sql = "DELETE FROM Sale WHERE id = ?";
            jdbcTemplate.update(sql, id);

            JOptionPane.showMessageDialog(null, "VENDA DELETADA COM SUCESSO!", "DELETE DE VENDA", JOptionPane.INFORMATION_MESSAGE );
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO DELETE DE VENDA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "ID DA VENDA INVÁLIDO OU VAZIO!", "ERRO NO DELETE DE VENDA", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void consultAll(DefaultTableModel tableModel) {
        try {
            String sql =
                "SELECT " +
                    "s.id AS sellId, " +
                    "u.name AS customerName, " +
                    "cl.name AS clothingName " +
                "FROM Sale s " +
                "INNER JOIN Customer c ON c.idUser = s.idCustomer " +
                "INNER JOIN `User` u ON u.id = c.idUser " +
                "INNER JOIN Clothings cl ON cl.id = s.idClothing " +
                "ORDER BY s.id";

            List<Sale> listSale = jdbcTemplate.query(
                sql,
                (ResultSet rs, int rowNum) -> {

                    Sale sale = new Sale();

                    Customer customer = new Customer();
                    customer.setName(rs.getString("customerName"));

                    Clothing clothing = new Clothing();
                    clothing.setName(rs.getString("clothingName"));

                    sale.setId(rs.getInt("sellId"));
                    sale.setCustomer(customer);
                    sale.setClothing(clothing);

                    return sale;
                }
            );

            tableModel.setRowCount(0);

            for (Sale sale : listSale) {
                tableModel.addRow(new Object[]{
                    sale.getId(),
                    sale.getCustomer().getName(),
                    sale.getClothing().getName()
                });
            }


        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO AO ACESSAR DADOS NO BANCO DE DADOS ", "ERRO NA CONSULTA DE VENDAS", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void consultAllByCustomer(DefaultTableModel tableModel, Customer customer) {
        try {
            if (customer == null || customer.getId() == null) {
                return;
            }

            String sql =
                "SELECT " +
                    "s.id AS sellId, " +
                    "u.name AS customerName, " +
                    "cl.name AS clothingName " +
                "FROM Sale s " +
                "INNER JOIN Customer c ON c.idUser = s.idCustomer " +
                "INNER JOIN `User` u ON u.id = c.idUser " +
                "INNER JOIN Clothings cl ON cl.id = s.idClothing " +
                "WHERE c.idUser = ? " +
                "ORDER BY s.id";

            List<Sale> listSale = jdbcTemplate.query(
                sql,
                new Object[]{customer.getId()},
                (ResultSet rs, int rowNum) -> {

                    Sale sale = new Sale();

                    Customer customerAux = new Customer();
                    customerAux.setId(customer.getId());
                    customerAux.setName(rs.getString("customerName"));

                    Clothing clothing = new Clothing();
                    clothing.setName(rs.getString("clothingName"));

                    sale.setId(rs.getInt("sellId"));
                    sale.setCustomer(customerAux);
                    sale.setClothing(clothing);

                    return sale;
                }
            );

            tableModel.setRowCount(0);

            for (Sale sale : listSale) {
                tableModel.addRow(new Object[]{
                    sale.getId(),
                    sale.getCustomer().getName(),
                    sale.getClothing().getName()
                });
            }

        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO PARA ACESSAR DADOS", "ERRO NA CONSULTA DE VENDAS", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void buyClothing(Integer idClothing, Customer customer) {
        try {
            String clothingSql = "SELECT id, name, color, size, price, brand " + "FROM Clothings " + "WHERE id = ?";

            Clothing clothing = jdbcTemplate.queryForObject(clothingSql, new Object[]{idClothing}, (ResultSet rs, int rowNum) -> {
                Clothing clothingAux = new Clothing();

                clothingAux.setId(rs.getInt("id"));
                clothingAux.setName(rs.getString("name"));
                clothingAux.setColor(rs.getString("color"));
                clothingAux.setSize(rs.getString("size"));
                clothingAux.setPrice(rs.getDouble("price"));
                clothingAux.setBrand(rs.getString("brand"));

                return clothingAux;
            });

            Sale sale = new Sale();
            sale.setCustomer(customer);
            sale.setClothing(clothing);

            save(sale);

            JOptionPane.showMessageDialog(null, "COMPRA REALIZADA COM SUCESSO!", "COMPRA DE ROUPA", JOptionPane.INFORMATION_MESSAGE);
        } 
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA COMPRA",JOptionPane.ERROR_MESSAGE);
        }
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "DADOS DA COMPRA INVÁLIDOS!", "ERRO NA COMPRA", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    
    public void consultSale(DefaultTableModel tableModel) {
        try {

            String sql =
                "SELECT c.id, c.name, c.color, c.size, c.price, c.brand, " +
                "CASE " + "WHEN p.idClothing IS NOT NULL THEN 'Calça' " + "WHEN t.idClothing IS NOT NULL THEN 'Camisa' " + "WHEN j.idClothing IS NOT NULL THEN 'Jaqueta' " + "END AS clothingType " +
                "FROM Clothings c " +
                "LEFT JOIN Pants p ON c.id = p.idClothing " +
                "LEFT JOIN TShirts t ON c.id = t.idClothing " +
                "LEFT JOIN Jackets j ON c.id = j.idClothing";

            List<Object[]> clothes = jdbcTemplate.query(sql,(ResultSet rs, int rowNum) -> {
                    return new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("color"),
                        rs.getString("size"),
                        rs.getDouble("price"),
                        rs.getString("brand"),
                        rs.getString("clothingType")
                    };
                }
            );

            tableModel.setRowCount(0);

            for (Object[] clothing : clothes) {
                tableModel.addRow(clothing);
            }
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA CONSULTA DE ROUPAS", JOptionPane.ERROR_MESSAGE);
        }
    }
}