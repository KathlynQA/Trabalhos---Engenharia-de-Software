package com.javagroup.lojaderoupas.view;

import com.javagroup.lojaderoupas.controller.ClothingController;
import com.javagroup.lojaderoupas.controller.EmployeeController;
import com.javagroup.lojaderoupas.controller.JacketController;
import com.javagroup.lojaderoupas.controller.TShirtController;
import com.javagroup.lojaderoupas.controller.PantsController;
import com.javagroup.lojaderoupas.controller.SaleController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ScreenEmployeeMenu extends javax.swing.JFrame {
    private static ScreenEmployeeMenu insUnic; 
    
    //Singleton
    public static ScreenEmployeeMenu generateScreenEmployeeMenu(){
        if(insUnic == null){
            insUnic = new ScreenEmployeeMenu();
        }
        return insUnic;
    }
    
    @Autowired
    public ScreenEmployeeMenu() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ReturnButton = new javax.swing.JButton();
        RegisterButton = new javax.swing.JButton();
        UpdateButton = new javax.swing.JButton();
        DeleteButton = new javax.swing.JButton();
        ConsultButton = new javax.swing.JButton();
        ConsultAllButton = new javax.swing.JButton();
        RegisterButton1 = new javax.swing.JButton();
        RegisterButton2 = new javax.swing.JButton();
        UpdateButton1 = new javax.swing.JButton();
        UpdateButton2 = new javax.swing.JButton();
        DeleteBuy = new javax.swing.JButton();
        ConsultButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        ReturnButton.setText("Voltar");
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        RegisterButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        RegisterButton.setText("Registrar Jaqueta");
        RegisterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterButtonActionPerformed(evt);
            }
        });

        UpdateButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        UpdateButton.setText("Atualizar Camisa");
        UpdateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateButtonActionPerformed(evt);
            }
        });

        DeleteButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        DeleteButton.setText("Deletar Roupa");
        DeleteButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteButtonActionPerformed(evt);
            }
        });

        ConsultButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ConsultButton.setText("Consultar Roupa");
        ConsultButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultButtonActionPerformed(evt);
            }
        });

        ConsultAllButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ConsultAllButton.setText("Consultar Todas as Roupas");
        ConsultAllButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultAllButtonActionPerformed(evt);
            }
        });

        RegisterButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        RegisterButton1.setText("Registrar Camisa");
        RegisterButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterButton1ActionPerformed(evt);
            }
        });

        RegisterButton2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        RegisterButton2.setText("Registrar Calça");
        RegisterButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterButton2ActionPerformed(evt);
            }
        });

        UpdateButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        UpdateButton1.setText("Atualizar Jaqueta");
        UpdateButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateButton1ActionPerformed(evt);
            }
        });

        UpdateButton2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        UpdateButton2.setText("Atualizar Calça");
        UpdateButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateButton2ActionPerformed(evt);
            }
        });

        DeleteBuy.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        DeleteBuy.setText("Deletar Venda");
        DeleteBuy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteBuyActionPerformed(evt);
            }
        });

        ConsultButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ConsultButton1.setText("Consultar Todas as Vendas");
        ConsultButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsultButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ReturnButton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 32, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(DeleteButton, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(ConsultButton, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(UpdateButton, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(UpdateButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(RegisterButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(64, 64, 64)
                                .addComponent(RegisterButton, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(56, 56, 56)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(RegisterButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(UpdateButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ConsultAllButton, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(ConsultButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DeleteBuy, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(88, 88, 88)))
                .addGap(52, 52, 52))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RegisterButton)
                    .addComponent(RegisterButton1)
                    .addComponent(RegisterButton2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(UpdateButton)
                    .addComponent(UpdateButton1)
                    .addComponent(UpdateButton2))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DeleteButton)
                    .addComponent(ConsultButton)
                    .addComponent(ConsultAllButton))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ConsultButton1)
                    .addComponent(DeleteBuy))
                .addContainerGap(52, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        ScreenUserLogin screenUserLogin = new ScreenUserLogin();
        screenUserLogin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ReturnButtonActionPerformed

    private void RegisterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterButtonActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        ClothingController clothingController = context.getBean(ClothingController.class);
        JacketController jacketController = context.getBean(JacketController.class);
        
        ScreenJacketCreate screenJacketCreate = new ScreenJacketCreate(clothingController, jacketController);
        screenJacketCreate.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RegisterButtonActionPerformed

    private void DeleteButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteButtonActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        ClothingController carController = context.getBean(ClothingController.class);
        
        ScreenClothingDelete screenCarDelete = new ScreenClothingDelete(carController);
        screenCarDelete.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DeleteButtonActionPerformed

    private void UpdateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateButtonActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        ClothingController clothingController = context.getBean(ClothingController.class);
        
        ScreenEmployeeTShirtSearch screenEmployeeTShirtSearch = new ScreenEmployeeTShirtSearch(clothingController);
        screenEmployeeTShirtSearch.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_UpdateButtonActionPerformed

    private void ConsultButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultButtonActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        ClothingController clothingController = context.getBean(ClothingController.class);
        
        ScreenClothingConsultUnique screenClothingConsultUnique = new ScreenClothingConsultUnique(clothingController);
        screenClothingConsultUnique.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ConsultButtonActionPerformed

    private void ConsultAllButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultAllButtonActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        ClothingController clothingController = context.getBean(ClothingController.class);
        
        ScreenClothingConsult screenClothingConsult = new ScreenClothingConsult(clothingController);
        screenClothingConsult.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ConsultAllButtonActionPerformed

    private void RegisterButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterButton1ActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        ClothingController clothingController = context.getBean(ClothingController.class);
        TShirtController tShirtController = context.getBean(TShirtController.class);
        
        ScreenTShirtCreate screenTShirtCreate = new ScreenTShirtCreate(clothingController, tShirtController);
        screenTShirtCreate.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RegisterButton1ActionPerformed

    private void RegisterButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterButton2ActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        ClothingController clothingController = context.getBean(ClothingController.class);
        PantsController pantsController = context.getBean(PantsController.class);
        
        ScreenPantsCreate screenPantsCreate = new ScreenPantsCreate(clothingController, pantsController);
        screenPantsCreate.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RegisterButton2ActionPerformed

    private void UpdateButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateButton1ActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        ClothingController clothingController = context.getBean(ClothingController.class);
        
        ScreenEmployeeJacketSearch screenEmployeeJacketSearch = new ScreenEmployeeJacketSearch(clothingController);
        screenEmployeeJacketSearch.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_UpdateButton1ActionPerformed

    private void UpdateButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateButton2ActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        ClothingController clothingController = context.getBean(ClothingController.class);
        
        ScreenEmployeePantsSearch screenEmployeepantsSearch = new ScreenEmployeePantsSearch(clothingController);
        screenEmployeepantsSearch.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_UpdateButton2ActionPerformed

    private void DeleteBuyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteBuyActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        SaleController saleController = context.getBean(SaleController.class);
        
        ScreenEmployeeSaleDelete screenEmployeeSaleDelete = new ScreenEmployeeSaleDelete(saleController);
        screenEmployeeSaleDelete.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_DeleteBuyActionPerformed

    private void ConsultButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsultButton1ActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        SaleController saleController = context.getBean(SaleController.class);
        
        ScreenEmployeeSaleConsult screenEmployeeSaleConsult = new ScreenEmployeeSaleConsult(saleController);
        screenEmployeeSaleConsult.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ConsultButton1ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
                EmployeeController employeeController = context.getBean(EmployeeController.class);
                new ScreenEmployeeMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ConsultAllButton;
    private javax.swing.JButton ConsultButton;
    private javax.swing.JButton ConsultButton1;
    private javax.swing.JButton DeleteButton;
    private javax.swing.JButton DeleteBuy;
    private javax.swing.JButton RegisterButton;
    private javax.swing.JButton RegisterButton1;
    private javax.swing.JButton RegisterButton2;
    private javax.swing.JButton ReturnButton;
    private javax.swing.JButton UpdateButton;
    private javax.swing.JButton UpdateButton1;
    private javax.swing.JButton UpdateButton2;
    // End of variables declaration//GEN-END:variables
}
