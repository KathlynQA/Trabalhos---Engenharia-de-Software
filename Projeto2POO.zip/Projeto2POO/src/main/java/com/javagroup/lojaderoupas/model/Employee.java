package com.javagroup.lojaderoupas.model;

import org.springframework.stereotype.Component;

@Component
public class Employee extends User{
    public Employee(Integer id, Integer category, String name, String address, String email, String phone, String password) {
        super(id, category, name, address, email, phone, password);
    }
    
    public Employee(Integer category, String name, String address, String email, String phone, String password) {
        super(category, name, address, email, phone, password);
    }
    
    public Employee() {
    }
}