
package com.javagroup.lojaderoupas.controller;

import com.javagroup.lojaderoupas.exception.UserException;
import com.javagroup.lojaderoupas.exception.WrongDataException;
import com.javagroup.lojaderoupas.model.Employee;
import static com.mysql.cj.util.StringUtils.isNullOrEmpty;

import javax.sql.DataSource;
import javax.swing.JOptionPane;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class EmployeeController {
    
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public EmployeeController(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }
    
    public void validateEmployee(Employee employee) {
        if (isNullOrEmpty(employee.getName()) || employee.getName() == null) {
                throw new NumberFormatException();
        }
    }
    
    public String returnPassword(String password, String name){
        if(isNullOrEmpty(password)){
            String passwordSql = "SELECT password FROM User WHERE name = ?";
            password = jdbcTemplate.queryForObject(passwordSql, new Object[]{name}, String.class);
        }
        
        return password;
    } 
    
    public String returnAddress(String address, String name){
        if(isNullOrEmpty(address)){
            String addressSql = "SELECT address FROM User WHERE name = ?";
            address = jdbcTemplate.queryForObject(addressSql, new Object[]{name}, String.class);
        }
        
        return address;
    } 
        
    public String returnEmail(String email, String name){
        if(isNullOrEmpty(email)){
            String emailSql = "SELECT email FROM User WHERE name = ?";
            email = jdbcTemplate.queryForObject(emailSql, new Object[]{name}, String.class);
        }
        
        return email;
    } 
            
    public String returnPhone(String phone, String name){
        if(isNullOrEmpty(phone)){
            String phoneSql = "SELECT phone FROM User WHERE name = ?";
            phone = jdbcTemplate.queryForObject(phoneSql, new Object[]{name}, String.class);
        }
        
        return phone;
    } 
    
    public void save(Employee employee) {
        try{
            validateEmployee(employee);
            
            String sqlUser = "INSERT INTO User (category, name, address, email, phone, password) VALUES (?, ?, ?, ?, ?, ?)";
            jdbcTemplate.update(sqlUser, employee.getCategory(), employee.getName(), employee.getAddress(), employee.getEmail(), employee.getPhone(), employee.getPassword());
            
            String checkSql = "SELECT id FROM User WHERE name = ?";
            Integer generatedUserId = jdbcTemplate.queryForObject(checkSql, new Object[]{employee.getName()}, Integer.class);
            
            String sqlCustomer = "INSERT INTO Employee (idUser) VALUES (?)";
            jdbcTemplate.update(sqlCustomer, generatedUserId);
            
            JOptionPane.showMessageDialog(null, "USUÁRIO CADASTRADO COM SUCESSO!", "CADASTRO DE USUÁRIO", 1);
        }
        
        catch (DataAccessException ex){
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO CADASTRO DE USUÁRIO", 0);
        }
        
        catch (NumberFormatException nfe){
            JOptionPane.showMessageDialog(null, "TIPO DE DADO CADASTRADO ERRADO OU VAZIO!", "ERRO NA ATUALIZAÇÃO NO CADASTRO DE USUÁRIO", 0);
        }
        
    } 
    
    public boolean loginEmployee(String name, String password) throws UserException {
        try {
            String checkSql = "SELECT COUNT(*) FROM User u INNER JOIN Employee e ON (u.id = e.idUser) WHERE u.name = ? AND u.password = ?";
            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{name, password}, Integer.class);
            
            if (count != 1) {
                throw new UserException();
            }

            return true;
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "LOGIN DE FUNCIONÁRIO", 0);
            return false;
        }
        
        catch (UserException ue) {
            ue.screenException();
            return false;
        }
    }
}