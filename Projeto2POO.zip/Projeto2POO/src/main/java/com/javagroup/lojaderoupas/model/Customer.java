package com.javagroup.lojaderoupas.model;

import org.springframework.stereotype.Component;

@Component
public class Customer extends User{
    private String cpf;

    public Customer(String cpf, Integer id, Integer category, String name, String address, String email, String phone, String password) {
        super(id, category, name, address, email, phone, password);
        this.cpf = cpf;
    }
    
    public Customer(String cpf, Integer category, String name, String address, String email, String phone, String password) {
        super(category, name, address, email, phone, password);
        this.cpf = cpf;
    }

    public Customer() {
    }
    
    
    public String getCpf() {
        return this.cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
}
