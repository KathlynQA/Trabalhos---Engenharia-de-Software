package com.javagroup.lojaderoupas.view;

import com.javagroup.lojaderoupas.controller.ClothingController;
import com.javagroup.lojaderoupas.exception.ClothingNotAvailableException;
import com.javagroup.lojaderoupas.model.Clothing;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ScreenClothingConsultUnique extends javax.swing.JFrame {
    private final ClothingController clothingController;
    
    @Autowired
    public ScreenClothingConsultUnique(ClothingController clothingController) {
        this.clothingController = clothingController;
        initComponents();
    }

    private void consultData() {
        try {
            Integer id = Integer.valueOf(FieldID.getText());
            Clothing clothing = clothingController.getClothing(id);

            DefaultTableModel tableModel =
                (DefaultTableModel) tableClothing.getModel();

            tableModel.setRowCount(0);

            if (clothing != null) {
                tableModel.addRow(new Object[]{
                    clothing.getId(),
                    clothing.getName(),
                    clothing.getColor(),
                    clothing.getSize(),
                    clothing.getPrice(),
                    clothing.getBrand()
                });
            }

        } 
        
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "ID DA ROUPA INVÁLIDO OU VAZIO!", "ERRO NA CONSULTA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (ClothingNotAvailableException ex) {
            JOptionPane.showMessageDialog(null, "ID DA ROUPA NÃO EXISTE!", "ERRO NA CONSULTA", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        table = new javax.swing.JScrollPane();
        tableClothing = new javax.swing.JTable();
        TextTitle = new javax.swing.JLabel();
        TextID = new javax.swing.JLabel();
        Plate = new javax.swing.JScrollPane();
        FieldID = new javax.swing.JTextPane();
        ButtonConsult = new javax.swing.JButton();
        ReturnButton6 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tableClothing.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nome", "Cor", "Tamanho", "Preço", "Marca"
            }
        ));
        table.setViewportView(tableClothing);

        TextTitle.setFont(new java.awt.Font("Lucida Sans", 1, 18)); // NOI18N
        TextTitle.setText("Consulta de Roupa");

        TextID.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        TextID.setText("ID:");

        Plate.setViewportView(FieldID);

        ButtonConsult.setText("Consultar");
        ButtonConsult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonConsultActionPerformed(evt);
            }
        });

        ReturnButton6.setText("Voltar");
        ReturnButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ReturnButton6)
                        .addGap(209, 209, 209)
                        .addComponent(TextTitle))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(TextID)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Plate, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(table, javax.swing.GroupLayout.PREFERRED_SIZE, 750, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(ButtonConsult)
                .addGap(347, 347, 347))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ReturnButton6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(table, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextID, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Plate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addComponent(ButtonConsult)
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonConsultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonConsultActionPerformed
        consultData();
    }//GEN-LAST:event_ButtonConsultActionPerformed

    private void ReturnButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButton6ActionPerformed
        ScreenEmployeeMenu screenEmployeeCarMenu = ScreenEmployeeMenu.generateScreenEmployeeMenu();
        screenEmployeeCarMenu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ReturnButton6ActionPerformed
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
                ClothingController clothingController = context.getBean(ClothingController.class);
                new ScreenClothingConsultUnique(clothingController).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonConsult;
    private javax.swing.JTextPane FieldID;
    private javax.swing.JScrollPane Plate;
    private javax.swing.JButton ReturnButton6;
    private javax.swing.JLabel TextID;
    private javax.swing.JLabel TextTitle;
    private javax.swing.JScrollPane table;
    private javax.swing.JTable tableClothing;
    // End of variables declaration//GEN-END:variables
}
