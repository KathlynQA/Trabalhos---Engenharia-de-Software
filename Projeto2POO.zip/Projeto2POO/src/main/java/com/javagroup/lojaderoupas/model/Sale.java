package com.javagroup.lojaderoupas.model;

public class Sale {
    private Integer id;
    private Customer customer;
    private Clothing clothing;

    public Sale() {
        id = 0;
        customer = new Customer();
        clothing = null;
    }

    public Sale(Integer id, Customer customer, Clothing clothing) {
        this.id = id;
        this.customer = customer;
        this.clothing = clothing;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Clothing getClothing() {
        return clothing;
    }

    public void setClothing(Clothing clothing) {
        this.clothing = clothing;
    }
}