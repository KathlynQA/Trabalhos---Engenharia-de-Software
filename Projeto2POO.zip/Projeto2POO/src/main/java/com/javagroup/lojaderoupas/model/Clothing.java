package com.javagroup.lojaderoupas.model;

public class Clothing {
    private Integer id;
    private String name;
    private String color;
    private String size;
    private double price;
    private String brand;

    public Clothing() {
    }

    public Clothing(Integer id, String name, String color, String size, double price, String brand) {
        this.id = id;
        this.name = name;
        this.color = color;
        this.size = size;
        this.price = price;
        this.brand = brand;
    }
    
    public Clothing(String name, String color, String size, double price, String brand) {
        this.name = name;
        this.color = color;
        this.size = size;
        this.price = price;
        this.brand = brand;
    }
    
    public Integer getId(){
        return id;
    }

    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }

    public String getSize() {
        return size;
    }

    public double getPrice() {
        return price;
    }

    public String getBrand() {
        return brand;
    }

    public void setId(Integer id){
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }
}