package com.javagroup.lojaderoupas.model;

public class TShirt extends Clothing {

    private String sleeveType;

    public TShirt() {
        super();
        sleeveType = "";
    }
    
    public TShirt(String name, String color, String size, double price, String brand, String sleeveType) {
        super(name, color, size, price, brand);
        this.sleeveType = sleeveType;
    }
    
    public TShirt(Integer id, String name, String color, String size, double price, String brand, String sleeveType) {
        super(id, name, color, size, price, brand);
        this.sleeveType = sleeveType;
    }

    public String getSleeveType() {
        return sleeveType;
    }

    public void setSleeveType(String sleeveType) {
        this.sleeveType = sleeveType;
    }
}