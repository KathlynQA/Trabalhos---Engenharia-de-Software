package com.javagroup.lojaderoupas.model;

public class Jacket extends Clothing {

    private boolean waterproof;

    public Jacket() {
        super();
        waterproof = false;
    }
    
    public Jacket(String name, String color, String size, double price, String brand, boolean waterproof) {
        super(name, color, size, price, brand);
        this.waterproof = waterproof;
    }

    public Jacket(Integer id, String name, String color, String size, double price, String brand, boolean waterproof) {
        super(id, name, color, size, price, brand);
        this.waterproof = waterproof;
    }

    public boolean isWaterproof() {
        return waterproof;
    }

    public void setWaterproof(boolean waterproof) {
        this.waterproof = waterproof;
    }
}