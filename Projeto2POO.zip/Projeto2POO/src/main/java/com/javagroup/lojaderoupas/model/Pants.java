package com.javagroup.lojaderoupas.model;

public class Pants extends Clothing {
    private String pantsType;

    public Pants() {
        super();
        pantsType = "";
    }
    
    public Pants(String name, String color, String size, double price, String brand, String pantsType) {
        super(name, color, size, price, brand);
        this.pantsType = pantsType;
    }
    
    public Pants(Integer id, String name, String color, String size, double price, String brand, String pantsType) {
        super(id, name, color, size, price, brand);
        this.pantsType = pantsType;
    }

    public String getPantsType() {
        return pantsType;
    }

    public void setPantsType(String pantsType) {
        this.pantsType = pantsType;
    }
}