package com.javagroup.lojaderoupas.view;

import com.javagroup.lojaderoupas.controller.ClothingController;
import com.javagroup.lojaderoupas.controller.CustomerController;
import com.javagroup.lojaderoupas.controller.EmployeeController;
import com.javagroup.lojaderoupas.controller.SaleController;
import com.javagroup.lojaderoupas.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ScreenCustomerMenu extends javax.swing.JFrame {
    private static ScreenCustomerMenu insUnic;
    private final Customer customer;
    
    @Autowired
    public ScreenCustomerMenu(Customer customer) {
        this.customer = customer;
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ReturnButton = new javax.swing.JButton();
        ClothingButton = new javax.swing.JButton();
        SalesButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        ReturnButton.setText("Voltar");
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        ClothingButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ClothingButton.setText("Comprar Roupas");
        ClothingButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClothingButtonActionPerformed(evt);
            }
        });

        SalesButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        SalesButton.setText("Visualizar Suas Compras");
        SalesButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalesButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ReturnButton)
                .addGap(416, 416, 416))
            .addGroup(layout.createSequentialGroup()
                .addGap(139, 139, 139)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(SalesButton, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ClothingButton, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ClothingButton)
                .addGap(47, 47, 47)
                .addComponent(SalesButton)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        CustomerController customerController = context.getBean(CustomerController.class);
        
        ScreenCustomerLogin screenCustomerLogin = ScreenCustomerLogin.geraScreenCustomerLogin(customerController);
        screenCustomerLogin.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ReturnButtonActionPerformed

    private void ClothingButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClothingButtonActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        SaleController saleController = context.getBean(SaleController.class);
        ClothingController clothingController = context.getBean(ClothingController.class);
        
        ScreenClothingBuy screenClothingBuy = new ScreenClothingBuy(saleController, clothingController, customer);
        screenClothingBuy.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ClothingButtonActionPerformed

    private void SalesButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalesButtonActionPerformed
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        SaleController saleController = context.getBean(SaleController.class);
        
        ScreenCustomerSaleConsult screenCustomerSaleConsult = new ScreenCustomerSaleConsult(saleController, customer);
        screenCustomerSaleConsult.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_SalesButtonActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
                EmployeeController employeeController = context.getBean(EmployeeController.class);
                Customer customer = new Customer();
                new ScreenCustomerMenu(customer).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ClothingButton;
    private javax.swing.JButton ReturnButton;
    private javax.swing.JButton SalesButton;
    // End of variables declaration//GEN-END:variables
}
