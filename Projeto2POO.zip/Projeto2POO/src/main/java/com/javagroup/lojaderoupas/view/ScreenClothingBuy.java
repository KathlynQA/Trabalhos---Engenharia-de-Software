package com.javagroup.lojaderoupas.view;

import com.javagroup.lojaderoupas.controller.ClothingController;
import com.javagroup.lojaderoupas.controller.SaleController;
import com.javagroup.lojaderoupas.exception.ClothingNotAvailableException;
import com.javagroup.lojaderoupas.model.Customer;
import javax.swing.table.DefaultTableModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ScreenClothingBuy extends javax.swing.JFrame {
    private final ClothingController clothingController;
    private final SaleController saleController;
    private Customer customer;
    
    @Autowired
    public ScreenClothingBuy(SaleController saleController, ClothingController clothingController, Customer customer) {
        this.saleController = saleController;
        this.clothingController = clothingController;
        this.customer = customer;
        initComponents();
        consultData();
    }

    private void consultData() {
        DefaultTableModel tableModel = (DefaultTableModel)tableClothing.getModel();
        saleController.consultSale(tableModel);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        table = new javax.swing.JScrollPane();
        tableClothing = new javax.swing.JTable();
        TextTitle = new javax.swing.JLabel();
        ReturnButton3 = new javax.swing.JButton();
        clothingText = new javax.swing.JLabel();
        clothingField = new javax.swing.JTextField();
        buyButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tableClothing.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Cor", "Tamanho", "Preço", "Marca"
            }
        ));
        tableClothing.setToolTipText("");
        table.setViewportView(tableClothing);

        TextTitle.setFont(new java.awt.Font("Lucida Sans", 1, 18)); // NOI18N
        TextTitle.setText("Consulta de Roupa");

        ReturnButton3.setText("Voltar");
        ReturnButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButton3ActionPerformed(evt);
            }
        });

        clothingText.setText("ID da Roupa:");

        clothingField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clothingFieldActionPerformed(evt);
            }
        });

        buyButton.setText("Comprar");
        buyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buyButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(clothingText)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(clothingField, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(buyButton))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ReturnButton3)
                        .addGap(211, 211, 211)
                        .addComponent(TextTitle))
                    .addComponent(table, javax.swing.GroupLayout.PREFERRED_SIZE, 750, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ReturnButton3))
                .addGap(30, 30, 30)
                .addComponent(table, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clothingText)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(clothingField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(buyButton)))
                .addContainerGap(44, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ReturnButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButton3ActionPerformed
        ScreenCustomerMenu screenCustomerMenu = new ScreenCustomerMenu(customer);
        screenCustomerMenu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ReturnButton3ActionPerformed

    private void buyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buyButtonActionPerformed
        try {
            Integer id = Integer.valueOf(clothingField.getText());
            Boolean validClothing = clothingController.verifyClothingId(id);

            if (validClothing) {
                ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
                saleController.buyClothing(id, customer);
            }
        } 
        
        catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Digite um ID válido.");
        } 
        
        catch (ClothingNotAvailableException cnae) {
            cnae.screenException();
        }
    }//GEN-LAST:event_buyButtonActionPerformed

    private void clothingFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clothingFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_clothingFieldActionPerformed
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
                SaleController saleController = context.getBean(SaleController.class);
                ClothingController clothingController = context.getBean(ClothingController.class);
                Customer customer = new Customer();
                new ScreenClothingBuy(saleController, clothingController, customer).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ReturnButton3;
    private javax.swing.JLabel TextTitle;
    private javax.swing.JButton buyButton;
    private javax.swing.JTextField clothingField;
    private javax.swing.JLabel clothingText;
    private javax.swing.JScrollPane table;
    private javax.swing.JTable tableClothing;
    // End of variables declaration//GEN-END:variables
}
