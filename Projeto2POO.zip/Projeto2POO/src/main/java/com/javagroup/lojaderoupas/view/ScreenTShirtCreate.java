package com.javagroup.lojaderoupas.view;

import com.javagroup.lojaderoupas.controller.ClothingController;
import com.javagroup.lojaderoupas.controller.TShirtController;
import com.javagroup.lojaderoupas.model.Clothing;
import com.javagroup.lojaderoupas.model.TShirt;
import javax.swing.JOptionPane;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ScreenTShirtCreate extends javax.swing.JFrame {
    private final ClothingController clothingController;
    private final TShirtController tShirtController;
    
    @Autowired
    public ScreenTShirtCreate(ClothingController clothingController, TShirtController tShirtController) {
        this.clothingController = clothingController;
        this.tShirtController = tShirtController;
        initComponents();
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TextTitle = new javax.swing.JLabel();
        TextName = new javax.swing.JLabel();
        Plate = new javax.swing.JScrollPane();
        fieldName = new javax.swing.JTextPane();
        TextColor = new javax.swing.JLabel();
        Chassis = new javax.swing.JScrollPane();
        fieldColor = new javax.swing.JTextPane();
        TextSize = new javax.swing.JLabel();
        Brand = new javax.swing.JScrollPane();
        fieldSize = new javax.swing.JTextPane();
        TextPrice = new javax.swing.JLabel();
        Model = new javax.swing.JScrollPane();
        fieldPrice = new javax.swing.JTextPane();
        TextBrand = new javax.swing.JLabel();
        Color = new javax.swing.JScrollPane();
        fieldBrand = new javax.swing.JTextPane();
        TextSleeveType = new javax.swing.JLabel();
        Year = new javax.swing.JScrollPane();
        fieldSleeveType = new javax.swing.JTextPane();
        ButtonRegister = new javax.swing.JButton();
        ReturnButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        TextTitle.setFont(new java.awt.Font("Lucida Sans", 1, 18)); // NOI18N
        TextTitle.setText("Registre a Camisa");

        TextName.setText("Nome:");

        Plate.setViewportView(fieldName);

        TextColor.setText("Cor:");

        Chassis.setViewportView(fieldColor);

        TextSize.setText("Tamanho:");

        Brand.setViewportView(fieldSize);

        TextPrice.setText("Preço:");

        Model.setViewportView(fieldPrice);

        TextBrand.setText("Marca:");

        Color.setViewportView(fieldBrand);

        TextSleeveType.setText("Tipo de Manga:");

        Year.setViewportView(fieldSleeveType);

        ButtonRegister.setText("Registrar Camisa");
        ButtonRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonRegisterActionPerformed(evt);
            }
        });

        ReturnButton.setText("Voltar");
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(TextSleeveType)
                                .addGap(18, 18, 18)
                                .addComponent(Year, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(TextBrand, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(TextSize, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(TextColor, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(TextName, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(TextPrice, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Color)
                                    .addComponent(Brand)
                                    .addComponent(Model)
                                    .addComponent(Chassis)
                                    .addComponent(Plate, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 108, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(ReturnButton)
                        .addGap(142, 142, 142)
                        .addComponent(TextTitle)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ButtonRegister)
                .addGap(225, 225, 225))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(ReturnButton)
                        .addGap(33, 33, 33))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(TextTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Plate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextName))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextColor)
                    .addComponent(Chassis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Brand, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextSize))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Model, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextPrice))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextBrand)
                    .addComponent(Color, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextSleeveType))
                .addGap(41, 41, 41)
                .addComponent(ButtonRegister)
                .addContainerGap(30, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonRegisterActionPerformed
        try {
            TShirt tShirt = new TShirt(fieldName.getText(), fieldColor.getText(), fieldSize.getText(), Double.parseDouble(fieldPrice.getText()), fieldBrand.getText(), fieldSleeveType.getText());
            tShirtController.save(tShirt);
        }
        
        catch(NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "TIPO DE DADO CADASTRADO ERRADO!", "ERRO NO CADASTRO DA CAMISA", 0);
        }
    }//GEN-LAST:event_ButtonRegisterActionPerformed

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        ScreenEmployeeMenu screenEmployeeClothingMenu = ScreenEmployeeMenu.generateScreenEmployeeMenu();
        screenEmployeeClothingMenu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ReturnButtonActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
                ClothingController clothingController = context.getBean(ClothingController.class);
                TShirtController tShirtController = context.getBean(TShirtController.class);
                new ScreenTShirtCreate(clothingController, tShirtController).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane Brand;
    private javax.swing.JButton ButtonRegister;
    private javax.swing.JScrollPane Chassis;
    private javax.swing.JScrollPane Color;
    private javax.swing.JScrollPane Model;
    private javax.swing.JScrollPane Plate;
    private javax.swing.JButton ReturnButton;
    private javax.swing.JLabel TextBrand;
    private javax.swing.JLabel TextColor;
    private javax.swing.JLabel TextName;
    private javax.swing.JLabel TextPrice;
    private javax.swing.JLabel TextSize;
    private javax.swing.JLabel TextSleeveType;
    private javax.swing.JLabel TextTitle;
    private javax.swing.JScrollPane Year;
    private javax.swing.JTextPane fieldBrand;
    private javax.swing.JTextPane fieldColor;
    private javax.swing.JTextPane fieldName;
    private javax.swing.JTextPane fieldPrice;
    private javax.swing.JTextPane fieldSize;
    private javax.swing.JTextPane fieldSleeveType;
    // End of variables declaration//GEN-END:variables
}
