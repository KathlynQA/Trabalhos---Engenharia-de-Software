package com.javagroup.lojaderoupas.controller;

import static ch.qos.logback.core.util.OptionHelper.isNullOrEmpty;

import com.javagroup.lojaderoupas.exception.IdDuplicatedException;
import com.javagroup.lojaderoupas.exception.IdDoesNotExistException;
import com.javagroup.lojaderoupas.model.Pants;
import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Controller;

@Controller
public class PantsController {
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public PantsController(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    private void validatePants(Pants pants) {
        if (isNullOrEmpty(pants.getName()) || isNullOrEmpty(pants.getColor()) || isNullOrEmpty(pants.getSize()) || pants.getPrice() <= 0 || isNullOrEmpty(pants.getBrand()) || isNullOrEmpty(pants.getPantsType())) {
            throw new NumberFormatException();
        }
    }

    public void save(Pants pants) throws IdDuplicatedException, NumberFormatException {
        try {
            validatePants(pants);

            String sql = "INSERT INTO Clothings " + "(name, color, size, price, brand) " + "VALUES (?, ?, ?, ?, ?)";
            KeyHolder keyHolder = new GeneratedKeyHolder();

            jdbcTemplate.update(connection -> { 
                PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

                ps.setString(1, pants.getName());
                ps.setString(2, pants.getColor());
                ps.setString(3, pants.getSize());
                ps.setDouble(4, pants.getPrice());
                ps.setString(5, pants.getBrand());
                return ps;
            }, keyHolder);

            int idClothing = keyHolder.getKey().intValue();
            String sql2 = "INSERT INTO Pants " + "(idClothing, pantsType) " +"VALUES (?, ?)";

            jdbcTemplate.update(sql2, idClothing, pants.getPantsType());
            pants.setId(idClothing);
            JOptionPane.showMessageDialog(null, "CALÇA CADASTRADA COM SUCESSO!", "CADASTRO DE CALÇA", JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO CADASTRO DE CALÇA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "DADO CADASTRADO ERRADO OU VAZIO!", "ERRO NO CADASTRO DE CALÇA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "TIPO DE DADO CADASTRADO ERRADO!", "ERRO NO CADASTRO DE CALÇA",JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IdDuplicatedException ide) {
            ide.screenException();
        }
    }

    public void update(Pants pants) throws IdDoesNotExistException, NumberFormatException {
        try {
            String checkSql = "SELECT COUNT(*) FROM Clothings WHERE id = ?";

            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{pants.getId()},Integer.class);
            
            if (count == 0) {
                throw new IdDoesNotExistException();
            }

            validatePants(pants);
            String sql = "UPDATE Clothings SET " + "name = ?, " + "color = ?, " + "size = ?, " + "price = ?, " + "brand = ? " + "WHERE id = ?";
            jdbcTemplate.update(sql, pants.getName(), pants.getColor(), pants.getSize(), pants.getPrice(), pants.getBrand(), pants.getId());
            String sql2 = "UPDATE Pants SET " + "pantsType = ? " + "WHERE idClothing = ?";
            jdbcTemplate.update(sql2, pants.getPantsType(), pants.getId());

            JOptionPane.showMessageDialog(null, "CALÇA ATUALIZADA COM SUCESSO!", "ATUALIZAÇÃO DE CALÇA", JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "DADO CADASTRADO ERRADO OU VAZIO!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "TIPO DE DADO CADASTRADO ERRADO!", "ERRO NA ATUALIZAÇÃO", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IdDoesNotExistException ide) {
            ide.screenException();
        }
    }

    public void delete(Integer id) {
        try {
            if (id == null) {
                throw new NumberFormatException();
            }

            String sql = "DELETE FROM Pants WHERE idClothing = ?";
            jdbcTemplate.update(sql, id);
            String sql2 = "DELETE FROM Clothings WHERE id = ?";
            jdbcTemplate.update(sql2, id);

            JOptionPane.showMessageDialog(null, "CALÇA DELETADA COM SUCESSO!", "DELETE DE CALÇA",JOptionPane.INFORMATION_MESSAGE);
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NO DELETE",JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(null, "ID INVÁLIDO OU VAZIO!", "ERRO NO DELETE",JOptionPane.ERROR_MESSAGE);
        }
    }

    public void consultAll(DefaultTableModel tableModel) {
        try {
            String sql = "SELECT c.id, c.name, c.color, c.size, " + "c.price, c.brand, p.pantsType " + "FROM Clothings c "+ "INNER JOIN Pants p ON c.id = p.idClothing";

            List<Pants> listPants = jdbcTemplate.query(
                sql,
                (ResultSet rs, int rowNum) -> {
                    Pants pants = new Pants();

                    pants.setId(rs.getInt("id"));
                    pants.setName(rs.getString("name"));
                    pants.setColor(rs.getString("color"));
                    pants.setSize(rs.getString("size"));
                    pants.setPrice(rs.getDouble("price"));
                    pants.setPantsType(rs.getString("pantsType"));
                    pants.setBrand(rs.getString("brand"));
                    return pants;
                }
            );

            tableModel.setRowCount(0);

            for (Pants pants : listPants) {
                tableModel.addRow(new Object[]{
                    pants.getId(),
                    pants.getName(),
                    pants.getColor(),
                    pants.getSize(),
                    pants.getPrice(),
                    pants.getPantsType(),
                    pants.getBrand(),
                });
            }
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "ERRO NA CONSULTA DE CALÇAS", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void consultPants(Integer id, DefaultTableModel tableModel) throws IdDoesNotExistException {
        try {
            String checkSql ="SELECT COUNT(*) FROM Clothings WHERE id = ?";
            int count = jdbcTemplate.queryForObject(checkSql, new Object[]{id}, Integer.class);

            if (count == 0) {
                throw new IdDoesNotExistException();
            }

            String sql = "SELECT c.id, c.name, c.color, c.size, " + "c.price, c.brand, p.pantsType " + "FROM Clothings c " + "INNER JOIN Pants p ON c.id = p.idClothing "+ "WHERE c.id = ?";
            Pants pants = jdbcTemplate.queryForObject(
                sql,
                new Object[]{id},
                (ResultSet rs, int rowNum) -> {
                    Pants pantsAux = new Pants();

                    pantsAux.setId(rs.getInt("id"));
                    pantsAux.setName(rs.getString("name"));
                    pantsAux.setColor(rs.getString("color"));
                    pantsAux.setSize(rs.getString("size"));
                    pantsAux.setPrice(rs.getDouble("price"));
                    pantsAux.setPantsType(rs.getString("pantsType"));
                    pantsAux.setBrand(rs.getString("brand"));
                    return pantsAux;
                }
            );

            tableModel.setRowCount(0);

            tableModel.addRow(new Object[]{
                pants.getId(),
                pants.getName(),
                pants.getColor(),
                pants.getSize(),
                pants.getPrice(),
                pants.getPantsType(),
                pants.getBrand()
            });
        } 
        
        catch (DataAccessException ex) {
            JOptionPane.showMessageDialog(null, "ERRO NA AÇÃO DO BANCO DE DADOS!", "CONSULTA DE CALÇA",JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (IdDoesNotExistException ide) {
            ide.screenException();
        }
    }
}