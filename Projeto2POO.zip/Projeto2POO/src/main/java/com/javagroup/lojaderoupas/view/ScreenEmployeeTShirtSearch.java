package com.javagroup.lojaderoupas.view;

import com.javagroup.lojaderoupas.controller.ClothingController;
import com.javagroup.lojaderoupas.controller.TShirtController;
import com.javagroup.lojaderoupas.exception.ClothingNotAvailableException;
import com.javagroup.lojaderoupas.model.TShirt;
import javax.swing.JOptionPane;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ScreenEmployeeTShirtSearch extends javax.swing.JFrame {
    private final ClothingController clothingController;

    @Autowired
    public ScreenEmployeeTShirtSearch(ClothingController clothingController) {
        this.clothingController = clothingController;
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TextTitle = new javax.swing.JLabel();
        ButtonSearch = new javax.swing.JButton();
        ReturnButton = new javax.swing.JButton();
        UserName = new javax.swing.JScrollPane();
        idField = new javax.swing.JTextPane();
        TextUser = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        TextTitle.setFont(new java.awt.Font("Lucida Sans", 1, 18)); // NOI18N
        TextTitle.setText("Consultar Campo");

        ButtonSearch.setText("Procurar Camisa");
        ButtonSearch.setActionCommand("");
        ButtonSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonSearchActionPerformed(evt);
            }
        });

        ReturnButton.setText("Voltar");
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        UserName.setViewportView(idField);

        TextUser.setText("ID da Roupa:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ButtonSearch)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(ReturnButton)
                            .addGap(71, 71, 71)
                            .addComponent(TextTitle))
                        .addGroup(layout.createSequentialGroup()
                            .addGap(22, 22, 22)
                            .addComponent(TextUser)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(UserName, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ReturnButton))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(TextUser)
                    .addComponent(UserName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(ButtonSearch)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ButtonSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonSearchActionPerformed
        try {
            Integer id = Integer.valueOf(idField.getText());
            TShirt tShirt = clothingController.getTShirt(id);
            ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

            TShirtController tShirtController = context.getBean(TShirtController.class);
            ScreenTShirtUpdate screenTShirtUpdate = new ScreenTShirtUpdate(clothingController, tShirtController, tShirt);
            screenTShirtUpdate.setVisible(true);
            this.dispose();
        } 
        
        catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "TIPO DE DADO CADASTRADO ERRADO!", "ERRO NA CONSULTA DA CAMISETA", JOptionPane.ERROR_MESSAGE);
        } 
        
        catch (ClothingNotAvailableException ex) {
            JOptionPane.showMessageDialog(null, "CAMISETA NÃO ENCONTRADA!", "ERRO NA CONSULTA", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_ButtonSearchActionPerformed

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        ScreenEmployeeMenu screenEmployeeClothingMenu = ScreenEmployeeMenu.generateScreenEmployeeMenu();
        screenEmployeeClothingMenu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_ReturnButtonActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
                ClothingController clothingController = context.getBean(ClothingController.class);
                new ScreenEmployeeTShirtSearch(clothingController).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonSearch;
    private javax.swing.JButton ReturnButton;
    private javax.swing.JLabel TextTitle;
    private javax.swing.JLabel TextUser;
    private javax.swing.JScrollPane UserName;
    private javax.swing.JTextPane idField;
    // End of variables declaration//GEN-END:variables
}
