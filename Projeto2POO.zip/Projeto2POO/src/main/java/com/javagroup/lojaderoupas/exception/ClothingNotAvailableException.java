package com.javagroup.lojaderoupas.exception;

import javax.swing.JOptionPane;


public class ClothingNotAvailableException extends Exception {
    public ClothingNotAvailableException() {
    }
    
    public void screenException(){
        JOptionPane.showMessageDialog(null, "ROUPA NÃO DISPONIVEL OU NÃO EXISTENTE!", "ERRO NA COMPRA", 0);
    }
}
