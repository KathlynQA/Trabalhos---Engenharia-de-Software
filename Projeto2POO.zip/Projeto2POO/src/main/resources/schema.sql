CREATE DATABASE IF NOT EXISTS DB;
USE DB;

CREATE TABLE IF NOT EXISTS User (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category INT NOT NULL,
    name VARCHAR(50) UNIQUE NOT NULL,
    address VARCHAR(50),
    email VARCHAR(70),
    phone VARCHAR(50),
    password VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS Customer (
    idUser INT PRIMARY KEY,
    cpf VARCHAR(50) NOT NULL,
    FOREIGN KEY (idUser) REFERENCES User(id)
);

CREATE TABLE IF NOT EXISTS Employee (
    idUser INT PRIMARY KEY,
    FOREIGN KEY (idUser) REFERENCES User(id)
);

CREATE TABLE IF NOT EXISTS Clothings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    color VARCHAR(50) NOT NULL,
    size VARCHAR(20) NOT NULL,
    price DOUBLE NOT NULL,
    brand VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS TShirts (
    idClothing INT PRIMARY KEY,
    sleeveType VARCHAR(50) NOT NULL,
    FOREIGN KEY (idClothing) REFERENCES Clothings(id)
);

CREATE TABLE IF NOT EXISTS Pants (
    idClothing INT PRIMARY KEY,
    pantsType VARCHAR(50) NOT NULL,
    FOREIGN KEY (idClothing) REFERENCES Clothings(id)
);

CREATE TABLE IF NOT EXISTS Jackets (
    idClothing INT PRIMARY KEY,
    waterproof BOOLEAN NOT NULL,
    FOREIGN KEY (idClothing) REFERENCES Clothings(id)
);

CREATE TABLE IF NOT EXISTS Sale (
    id INT AUTO_INCREMENT PRIMARY KEY,
    idCustomer INT NOT NULL,
    idClothing INT NOT NULL,
    FOREIGN KEY (idCustomer) REFERENCES Customer(idUser),
    FOREIGN KEY (idClothing) REFERENCES Clothings(id) ON DELETE CASCADE
);


-- =====================================================
-- USERS
-- =====================================================

INSERT INTO `User`
    (category, name, address, email, phone, password)
VALUES
    (1, 'Gabriel', 'Rua das Flores, 100', 'gabriel@email.com', '11999990001', '123456'),
    (1, 'Lucas', 'Rua Central, 250', 'lucas@email.com', '11999990002', '123456'),
    (1, 'Mariana', 'Av. Brasil, 500', 'mariana@email.com', '11999990003', '123456'),
    (1, 'Ana', 'Rua Paulista, 800', 'ana@email.com', '11999990004', '123456'),
    (1, 'Pedro', 'Rua do Comércio, 120', 'pedro@email.com', '11999990005', '123456'),

    (2, 'Carlos', 'Rua das Palmeiras, 50', 'carlos@loja.com', '11988880001', 'admin123'),
    (2, 'Juliana', 'Av. Principal, 300', 'juliana@loja.com', '11988880002', 'admin123'),
    (2, 'Rafael', 'Rua São Paulo, 450', 'rafael@loja.com', '11988880003', 'admin123');


-- =====================================================
-- CUSTOMERS
-- idUser corresponde aos IDs 1 até 5
-- =====================================================

INSERT INTO Customer
    (idUser, cpf)
VALUES
    (1, '12345678901'),
    (2, '23456789012'),
    (3, '34567890123'),
    (4, '45678901234'),
    (5, '56789012345');


-- =====================================================
-- EMPLOYEES
-- idUser corresponde aos IDs 6 até 8
-- =====================================================

INSERT INTO Employee
    (idUser)
VALUES
    (6),
    (7),
    (8);


-- =====================================================
-- CLOTHINGS
-- =====================================================

INSERT INTO Clothings
    (id, name, color, size, price, brand)
VALUES
    (1, 'Camiseta Básica', 'Branca', 'M', 49.90, 'Nike'),
    (2, 'Camiseta Oversized', 'Preta', 'G', 89.90, 'Adidas'),
    (3, 'Camiseta Polo', 'Azul', 'M', 119.90, 'Lacoste'),
    (4, 'Camiseta Esportiva', 'Vermelha', 'G', 99.90, 'Puma'),

    (5, 'Calça Jeans', 'Azul', '42', 159.90, 'Levis'),
    (6, 'Calça Cargo', 'Verde', '40', 189.90, 'Nike'),
    (7, 'Calça Moletom', 'Cinza', 'M', 129.90, 'Adidas'),

    (8, 'Jaqueta Jeans', 'Azul', 'G', 249.90, 'Levis'),
    (9, 'Jaqueta Corta-Vento', 'Preta', 'M', 299.90, 'Nike'),
    (10, 'Jaqueta Impermeável', 'Verde', 'G', 349.90, 'North Face');


-- =====================================================
-- TSHIRTS
-- =====================================================

INSERT INTO TShirts
    (idClothing, sleeveType)
VALUES
    (1, 'Curta'),
    (2, 'Curta'),
    (3, 'Curta'),
    (4, 'Longa');


-- =====================================================
-- PANTS
-- =====================================================

INSERT INTO Pants
    (idClothing, pantsType)
VALUES
    (5, 'Jeans'),
    (6, 'Cargo'),
    (7, 'Moletom');


-- =====================================================
-- JACKETS
-- =====================================================

INSERT INTO Jackets
    (idClothing, waterproof)
VALUES
    (8, FALSE),
    (9, TRUE),
    (10, TRUE);


-- =====================================================
-- SALES
-- =====================================================

INSERT INTO Sale
    (idCustomer, idClothing)
VALUES
    (1, 1),
    (1, 5),
    (2, 2),
    (2, 8),
    (3, 3),
    (3, 6),
    (4, 4),
    (4, 9),
    (5, 7),
    (5, 10);